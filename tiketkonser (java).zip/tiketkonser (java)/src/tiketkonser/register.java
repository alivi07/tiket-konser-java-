package tiketkonser;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.*;

class register extends JFrame {

    private String id, nama, nohp, umur;
    private boolean value;
    private ArrayList<DataRegister> simpanRegister = new ArrayList<DataRegister>();

    public void setDataRegister(String id, String nama, String nohp, String umur) {
        simpanRegister.add(new DataRegister(id, nama, nohp, umur));
    }

    public void setid(String id) {
        this.id = id;
    }

    public void setnama(String nama) {
        this.nama = nama;
    }

    public void nohp(String nohp) {
        this.nohp = nohp;
    }

    public void umur(String umur) {
        this.umur = umur;
    }

    String database = "jdbc:mysql://localhost/evaluasi";
    String username = "root";
    String password = "";
    Connection koneksi;
    Statement statement;

    JLabel lregister = new JLabel("REGISTER");
    JLabel lid = new JLabel("ID");
    JTextField tid = new JTextField();
    JLabel lnama = new JLabel("Nama");
    JTextField tnama = new JTextField(25);
    JLabel lnohp = new JLabel("No HP");
    JTextField tnohp = new JTextField(12);
    JLabel lumur = new JLabel("Umur");
    JTextField tumur = new JTextField(3);
    JButton btnsave = new JButton("save");
    JButton btnback = new JButton("back");
    JButton btncancel = new JButton("cancel");

    public register() {
        setTitle("REGISTER");
        setDefaultCloseOperation(3);
        setSize(400, 400);

        setLayout(null);
        add(lregister);
        add(lid);
        add(lnama);
        add(lnohp);
        add(lumur);
        add(tid);
        add(tnama);
        add(tnohp);
        add(tumur);
        add(btnsave);
        add(btnback);
        add(btncancel);

        lregister.setBounds(130, 30, 100, 20);
        lid.setBounds(10, 70, 100, 20);
        tid.setBounds(110, 70, 150, 20);
        lnama.setBounds(10, 110, 100, 20);
        tnama.setBounds(110, 110, 150, 20);
        lnohp.setBounds(10, 150, 100, 20);
        tnohp.setBounds(110, 150, 150, 20);
        lumur.setBounds(10, 190, 100, 20);
        tumur.setBounds(110, 190, 60, 20);
        btnsave.setBounds(70, 240, 80, 20);
        btnback.setBounds(160, 240, 80, 20);
        btncancel.setBounds(250, 240, 80, 20);
        setLocationRelativeTo(null);
        setVisible(true);

        btnsave.addActionListener(new save());
        btnback.addActionListener(new back());
        btncancel.addActionListener(new cancel());

    }

    public class save implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            try {
                Class.forName("com.mysql.jdbc.Driver");
                koneksi = DriverManager.getConnection(database, username, password);
                statement = koneksi.createStatement();
                statement.executeUpdate("insert into registrasi values('" + tid.getText() + "','" + tnama.getText() + "','" + tnohp.getText() + "','" + tumur.getText() + "')");
                JOptionPane.showMessageDialog(null, "Data berhasil disimpan");
                String id = tid.getText();
                String nama = tnama.getText();
                String nohp = tnohp.getText();
                String umur = tumur.getText();
                total x = new total(id,nama,nohp,umur);
                 dispose();
                new menu();
                
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Data gagal disimpan");
            } catch (ClassNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Driver tidak ditemukan");
            }

        }
    }

    public class back implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            dispose();
            new menu();
        }
    }

    public class cancel implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            setVisible(false);
        }
    }
}
