/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tiketkonser;

/**
 *
 * @author Alivi Milova
 */
class DataTiket {

    String id, nama, nohp, umur,tiket,jumlah;

    public DataTiket(String id, String nama, String nohp, String umur,String tiket, String jumlah) {
        this.id = id;
        this.nama = nama;
        this.nohp = nohp;
        this.umur = umur;
        this.tiket = tiket;
        this.jumlah = jumlah;
    }

    DataTiket(String tiket, String jum, Double total) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    DataTiket(String tiket, String jum, String total) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getid() {
        return id;
    }

    public String getnama() {
        return nama;
    }

    public String nohp() {
        return nohp;
    }

    public String umur() {
        return umur;
    }
    public String tiket() {
        return tiket;
    }

    public String jumlah() {
        return jumlah;
    }
}
