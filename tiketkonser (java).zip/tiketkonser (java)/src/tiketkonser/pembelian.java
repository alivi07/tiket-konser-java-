package tiketkonser;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class pembelian extends JFrame {

    pembelian(String tiket, String jum, Double total) {
        Double kembali;
        JLabel judul = new JLabel("DATA PEMBELIAN");
        JLabel ltiket = new JLabel("Jenis Tiket = " + tiket);
        JLabel lplatinum = new JLabel("Jumlah   = " + jum);
        JLabel bayar = new JLabel("Uang Masuk ");
        JTextField tbayar = new JTextField();
        JLabel hasil = new JLabel("Total Bayar  = ");
        JTextField h = new JTextField("" + total);//muncul hasil perkalian antara harga tiket yg dipilih dengan jumlah

        kembali = Double.parseDouble(tbayar.getText()) - total;

        JLabel kembalian = new JLabel("Uang Kembali" + kembali);
        JTextField k = new JTextField("" + kembali); //keluar hasil kembalian uang , uang masuk - hasil
        JButton submit = new JButton("submit");
        JButton back = new JButton("back");
        JButton cancel = new JButton("cancel");

        setTitle("MENU PEMBELIAN");
        setDefaultCloseOperation(3);
        setSize(700, 700);

        setLayout(null);
        add(judul);
        add(ltiket);
        add(lplatinum);
        add(bayar);
        add(tbayar);
        add(hasil);
        add(h);
        add(kembalian);
        add(k);
        add(submit);
        add(back);
        add(cancel);

        judul.setBounds(120, 30, 100, 20);
        ltiket.setBounds(10, 80, 200, 20);
        lplatinum.setBounds(10, 110, 200, 20);
        bayar.setBounds(30, 360, 200, 20);
        tbayar.setBounds(150, 360, 200, 20);
        hasil.setBounds(30, 390, 200, 20);
        h.setBounds(150, 390, 200, 20);
        kembalian.setBounds(30, 420, 200, 20);
        k.setBounds(150, 420, 200, 20);
        submit.setBounds(80, 500, 80, 20);
        back.setBounds(190, 500, 80, 20);
        cancel.setBounds(300, 500, 80, 20);

        setVisible(true);

        submit.addActionListener(new submit());
        back.addActionListener(new back());
        cancel.addActionListener(new cancel());
    }

    public class submit implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            dispose();
            new menu();
        }
    }

    public class back implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            dispose();
            new menu();
        }
    }

    public class cancel implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            setVisible(false);
        }
    }

    public class DataTiket {

        String tiket, jum;
        Double total;
        public DataTiket(String tiket, String jum, Double total) {
            this.tiket = tiket;
            this.jum = jum;
            this.total = total;
        }
        public String gettiket() {
            return tiket;
        }
        public String gejum() {
            return jum;
        }
        public Double gettotal() {
            return total;
        }
    }
}
