package tiketkonser;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;

class menu extends JFrame {

    String id, nama, nohp, umur, tiket, jum;
    Double total;

    JLabel menu = new JLabel("MENU");
    JRadioButton register = new JRadioButton("Register");
    JRadioButton bttiket = new JRadioButton("Pilih Tiket");
    JRadioButton pembelian = new JRadioButton("Pembelian");
    JRadioButton bttotal = new JRadioButton("Total Pembayaran");
    JButton cancel = new JButton("cancel");

    public menu() {
        this.id = id;
        this.nama = nama;
        this.nohp = nohp;
        this.umur = umur;

        setTitle("MENU");
        setDefaultCloseOperation(3);
        setSize(400, 400);

        ButtonGroup group = new ButtonGroup();
        group.add(register);
        group.add(bttiket);
        group.add(pembelian);
        group.add(bttotal);

        setLayout(null);
        add(menu);
        add(register);
        add(bttiket);
        add(pembelian);
        add(bttotal);
        add(cancel);

        menu.setBounds(120, 30, 100, 20);
        register.setBounds(40, 70, 200, 20);
        bttiket.setBounds(40, 110, 200, 20);
        pembelian.setBounds(40, 150, 200, 20);
        bttotal.setBounds(40, 190, 200, 20);
        cancel.setBounds(70, 250, 90, 20);
        setLocationRelativeTo(null);
        setVisible(true);

        register.addActionListener(new GoRegister());
        bttiket.addActionListener(new GoTiket());
        pembelian.addActionListener(new GoPembelian());
        bttotal.addActionListener(new GoTotal());
        cancel.addActionListener(new cancel());
    }

    public class GoRegister implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            dispose();
            new register();
        }
    }

    public class GoTiket implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            dispose();
            new tiket(tiket, jum, total);
        }
    }

    public class GoPembelian implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            dispose();
            new pembelian(tiket, jum, total);
        }
    }

    public class GoTotal implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            dispose();
            new total(id, nama, nohp, umur);
        }
    }

    public class cancel implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            setVisible(false);
        }
    }
}
