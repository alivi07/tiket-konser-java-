package tiketkonser;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 *
 * @author Alivi Milova
 */
public class total extends JFrame {

    total(String id, String nama, String nohp, String umur) {

        JLabel total = new JLabel("DATA PEMESANAN TOTAL");
        JLabel data = new JLabel("Data Register :");
        //muncul data dari register
        JLabel lid = new JLabel("ID   = " + id);
        JLabel lnama = new JLabel("NAMA   = " + nama);
        JLabel lnohp = new JLabel("NO HP   = " + nohp);
        JLabel lumur = new JLabel("UMUR  = " + umur);
        JLabel tiket = new JLabel("Data Tiket  :");
        //muncul data dari tiket
        JLabel uang = new JLabel("Total Pembayaran :");
        //muncul data dari pembelian
        JButton oke = new JButton("OKE");
        JButton cancel = new JButton("CANCEL");

        setTitle("TOTAL");
        setDefaultCloseOperation(3);
        setSize(600, 600);

        setLayout(null);
        add(total);
        add(data);
        add(lid);
        add(lnama);
        add(lnohp);
        add(lumur);
        add(tiket);
        add(uang);
        add(oke);
        add(cancel);

        total.setBounds(70, 10, 200, 20);
        data.setBounds(30, 60, 150, 20);
        lid.setBounds(30, 90, 150, 20);
        lnama.setBounds(30, 120, 150, 20);
        lnohp.setBounds(30, 150, 150, 20);
        lumur.setBounds(30, 180, 150, 20);
        tiket.setBounds(30, 220, 150, 20);
        uang.setBounds(30, 360, 150, 20);
        oke.setBounds(60, 460, 80, 20);
        cancel.setBounds(150, 460, 80, 20);

        setVisible(true);

        oke.addActionListener(new oke());
        cancel.addActionListener(new cancel());
    }

    public class oke implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            dispose();
            new login();
        }
    }

    public class cancel implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            setVisible(false);
        }
    }

    public class DataRegister {

        String id, nama, nohp, umur;

        public DataRegister(String id, String nama, String nohp, String umur) {
            this.id = id;
            this.nama = nama;
            this.nohp = nohp;
            this.umur = umur;
        }

        public String getid() {
            return id;
        }

        public String getnama() {
            return nama;
        }

        public String nohp() {
            return nohp;
        }

        public String umur() {
            return umur;
        }

    }
}
