package tiketkonser;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

class login extends JFrame {
    
    String id, nama, nohp, umur;
    JLabel llogin = new JLabel("LOG IN");
    JLabel lusername = new JLabel("Username");
    JTextField tusername = new JTextField(10);
    JLabel lpassword = new JLabel("Password");
    JPasswordField ppassword = new JPasswordField(10);
    JButton btnnext = new JButton("next");
    JButton btncancel = new JButton("cancel");
    
    public login() {
        this.id = id;
        this.nama = nama;
        this.nohp = nohp;
        this.umur = umur;
        setTitle("LOG IN");
        setDefaultCloseOperation(3);
        setSize(300, 300);
        
        setLayout(null);
        add(llogin);
        add(lusername);
        add(lpassword);
        add(tusername);
        add(ppassword);
        add(btnnext);
        add(btncancel);
        
        llogin.setBounds(120, 30, 100, 20);
        lusername.setBounds(10, 70, 100, 20);
        tusername.setBounds(110, 70, 140, 20);
        lpassword.setBounds(10, 110, 100, 20);
        ppassword.setBounds(110, 110, 140, 20);
        btnnext.setBounds(40, 160, 80, 20);
        btncancel.setBounds(140, 160, 80, 20);
        setLocationRelativeTo(null);
        setVisible(true);
        
        btnnext.addActionListener(new next());
        btncancel.addActionListener(new cancel());
    }
    
    public class next implements ActionListener {
        
        @Override
        public void actionPerformed(ActionEvent e) {
            setPassword();
            setUsername();
            if (getUsername().equals(tusername.getText()) && getPassword().equals(ppassword.getText())) {
                JOptionPane.showMessageDialog(null, "Log In Berhasil");
                dispose();
                new menu();
                
            } else {
                JOptionPane.showMessageDialog(null, "Log In Gagal");
                
            }
            
        }
        
        private String Username, Password;
        boolean value;
        
        public String getUsername() {
            return Username;
        }
        
        public void setUsername() {
            Username = "alivi";
        }
        
        public String getPassword() {
            return Password;
        }
        
        public void setPassword() {
            Password = "123";
        }
        
        public void setvalue(boolean value) {
            this.value = value;
        }
        
        public boolean getvalue() {
            return value;
        }
    }
    
    public class cancel implements ActionListener {
        
        @Override
        public void actionPerformed(ActionEvent e) {
            setVisible(false);
            
        }
    }
    
}
