package tiketkonser;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

class tiket extends JFrame {

    private String tiket, jum;
    private Double total;
    private boolean value;
    private ArrayList<DataTiket> simpanTiket = new ArrayList<DataTiket>();

    public void setDataRegister(String tiket, String jum, Double total) {
        simpanTiket.add(new DataTiket(tiket, jum, total));
    }

    public void setjum(String jum) {
        this.jum = jum;
    }

    public void settotal(Double total) {
        this.total = total;
    }

    public void settiket(String tiket) {
        this.tiket = tiket;
    }

    String database = "jdbc:mysql://localhost/evaluasi";
    String username = "root";
    String password = "";
    Connection koneksi;
    Statement statement;

    JLabel daftar = new JLabel("DAFTAR TIKET G-DRAGON");
    JLabel pilih = new JLabel("Pilih Tiket :");
    JRadioButton gold = new JRadioButton("GOLD >>> RP 5.000.000");
    JRadioButton silver = new JRadioButton("SILVER >>> RP 4.000.000");
    JRadioButton platinum = new JRadioButton("PLATINUM >>> RP 3.000.000");
    JLabel jumlah = new JLabel("Jumlah ");
    JTextField jml = new JTextField();
    JButton choice = new JButton("choice");
    JButton back = new JButton("back");
    JButton cancel = new JButton("cancel");

    public tiket(String tiket, String jum, Double total) {

        setTitle("MENU TIKET");
        setDefaultCloseOperation(3);
        setSize(500, 500);

        ButtonGroup group = new ButtonGroup();
        group.add(gold);
        group.add(silver);
        group.add(platinum);

        setLayout(null);
        add(daftar);
        add(pilih);
        add(gold);
        add(silver);
        add(platinum);
        add(jumlah);
        add(jml);
        add(choice);
        add(back);
        add(cancel);

        daftar.setBounds(120, 30, 300, 20);
        pilih.setBounds(10, 70, 100, 20);
        gold.setBounds(10, 110, 250, 20);
        silver.setBounds(10, 190, 250, 20);
        platinum.setBounds(10, 270, 250, 20);
        jumlah.setBounds(30, 310, 100, 20);
        jml.setBounds(100, 310, 50, 20);
        choice.setBounds(70, 370, 90, 20);
        back.setBounds(170, 370, 90, 20);
        cancel.setBounds(270, 370, 90, 20);

        setLocationRelativeTo(null);
        setVisible(true);

        choice.addActionListener(new Choice());
        back.addActionListener(new Cancel());
        cancel.addActionListener(new Cancel());
    }

    public class Choice implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            try {
                Double total;
                String tiket;
                String jum = jml.getText();

                if (gold.isSelected()) {
                    tiket = gold.getText();
                    total = 5000000 * (Double.parseDouble(jum));
                } else if (silver.isSelected()) {
                    tiket = silver.getText();
                    total = 4000000 * (Double.parseDouble(jum));
                } else {
                    tiket = platinum.getText();
                    total = 3000000 * (Double.parseDouble(jum));
                }
                // jum = String.valueOf(total);
                Class.forName("com.mysql.jdbc.Driver");
                koneksi = DriverManager.getConnection(database, username, password);
                statement = koneksi.createStatement();
                statement.executeUpdate("insert into tiketkonser values('" + tiket + "','" + jml.getText() + "')");
                JOptionPane.showMessageDialog(null, "Data berhasil disimpan");
                dispose();
                new menu();
                pembelian y = new pembelian(tiket, jum, total);

            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Data gagal disimpan");
            } catch (ClassNotFoundException ex) {
                JOptionPane.showMessageDialog(null, "Driver tidak ditemukan");
            }

        }
    }

    public class back implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            dispose();
            new menu();
        }
    }

    public class Cancel implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            setVisible(false);
        }
    }
}
