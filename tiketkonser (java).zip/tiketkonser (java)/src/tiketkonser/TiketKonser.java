package tiketkonser;

import java.util.Scanner;
import javax.swing.*;


class TiketKonser {
    //class GUI
    public static void main(String[] args) {
       login a = new login ();
    }

}
