package tiketkonser;

class DataRegister {

    static void add(DataRegister dataRegister) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    String id, nama, nohp, umur;

    public DataRegister(String id, String nama, String nohp, String umur) {
        this.id = id;
        this.nama = nama;
        this.nohp = nohp;
        this.umur = umur;
    }

    public String getid() {
        return id;
    }

    public String getnama() {
        return nama;
    }

    public String nohp() {
        return nohp;
    }

    public String umur() {
        return umur;
    }

}
